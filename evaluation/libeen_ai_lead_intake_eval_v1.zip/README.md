# Libeen AI Lead Intake V0 — Synthetic Evaluation Benchmark

Versión **1.0.0** · **15/11/2026** · idioma **es-ES** · datos 100 % ficticios.

## Objetivo y alcance

Evaluar de forma reproducible un copiloto comercial interno, no un motor de elegibilidad financiera. Se diferencian extracción B, incidencias D, siguiente intervención E y reanálisis. La referencia semántica ha sido anotada deliberadamente sin tomar la salida de un modelo o del producto como verdad. No son conversaciones de clientes reales y no se afirma que Libeen use estos criterios comerciales.

Se entregan **24 casos iniciales, 8 continuaciones y 32 snapshots**. Distribución inicial: 6 sencillos, 6 incompletos/ambiguos, 4 atribución difícil, 4 contradicciones/rectificaciones y 4 sensibles/excepcionales. Los snapshots de continuación llevan todo el historial anterior seguido de nuevos turnos; cada caso conserva la misma identidad `caseId`.

## Archivos

- `cases.jsonl`: un registro JSON por snapshot para alimentar el sistema (sin respuestas esperadas). Claves `caseId`, `snapshotId`, `category`, `difficulty`, `isContinuation`, `previousSnapshotId`, `conversation`.
- `gold.jsonl`: mismo `snapshotId`; contiene extracción, prohibiciones, incidencias, intervención ideal, invariantes, modos de fallo y notas. **No alimentar este archivo al LLM en la evaluación.**
- `manifest.json`: versión, distribución, pares antes/después y cobertura.
- `validation_report.md`: validaciones realizadas y límites.
- `validate_dataset.py`: validador reproducible, solo biblioteca estándar Python 3.10+.

## Contrato del benchmark

`conversation` es texto bruto con turnos separados por línea en blanco. Solo se permiten prefijos `Cliente:`, `Libeen:` o `Asesor:`. Para la extracción, `Cliente` se interpreta como `role=customer` y los otros dos como `role=advisor`. Numerar **todos** los turnos desde `m1`, sin omitir el asesor. Un audio sin transcripción se registra como un turno independiente (`Cliente: [audio de 0:45]`), sin hechos inferidos.

`expectedExtraction` tiene las siete claves `interest`, `location`, `horizon`, `buyers`, `income`, `savings`, `debts` (cada una un array). Los candidatos contienen exactamente los nueve atributos del contrato (`field`, `value`, `messageId`, `quote`, `precision`, `subject`, `incomeBasis`, `debtIncluded`, `uncertainty`). Las unidades y períodos escritos permanecen textuales; por ejemplo 41.000 € brutos/año nunca se transforma en netos/mes.

`expectedIssues`: cada incidencia incluye `type` (`missing`, `ambiguous`, `inaccessible`, `sensitive`), `field` o `messageId` si procede, `effect` (`block`/`warning`) y `equivalenceGroup` para evitar contar dos veces la misma incertidumbre. `block` significa bloquear **la siguiente acción que depende de ello** o escalar revisión, no prohibir toda interacción.

`expectedIntervention.type`: `clarification` (una pregunta principal), `human_review` (revisión/derivación, con texto ilustrativo), `none` (no hace falta pregunta prioritaria; puede existir un siguiente paso comercial no automático). Los ejemplos **no requieren coincidencia literal**.

`annotationNotes.assertionRelations` distingue `explicit_correction`, `clarification`, `unresolved_conflict`, `different_periods`, `compatible_locations` o `intent_reversal`; el motor puede usar otra representación siempre que preserve semántica. El `gold` de una continuación conserva las aserciones antiguas aunque estén corregidas; la interfaz operativa debe utilizar el valor vigente solo si la corrección es inequívoca.

## Ejecución

Desde este directorio:

```bash
python3 validate_dataset.py
```

Para ejecutar contra el endpoint local ya arrancado (`POST /api/intake`), hay que adaptar el cuerpo a su contrato real, que **no consta en el material proporcionado**. No se presupone una respuesta ni se simula una validación de integración. Ejemplo mínimo para recorrer el corpus sin inventar el DTO del endpoint:

```python
import json
for line in open('cases.jsonl', encoding='utf-8'):
    snapshot = json.loads(line)
    print(snapshot['snapshotId'], snapshot['conversation'][:80])
    # TODO: preparar el payload exacto de POST /api/intake según la API real
```

Cuando se conozca el DTO, enviar cada `conversation` de `cases.jsonl` como input, guardar la respuesta junto con `snapshotId`, comparar con el registro del mismo ID en `gold.jsonl`. Ejecutar primero los 24 S0 y luego los 8 pares S0→S1, asegurando que no se mezclan expedientes.

## Cómo puntuar sin ocultar riesgos

1. **B – Extracción:** matching semántico por campo y evidencia; exigir que `quote` pertenezca a `messageId` de cliente. Medir cobertura, precisión, sujeto, neto/bruto, períodos, rango, valores inventados, y severidad de atribuciones erróneas.
2. **D – Incidencias:** comparar tipo, justificación, prioridad/efecto y `equivalenceGroup`. Un rango útil no tiene por qué ser `ambiguous`. Contar errores por grupos de incertidumbre, no por frases duplicadas.
3. **E – Intervención:** comparar tipo y objetivo con el estado del caso; evaluar ausencia de preguntas ya respondidas, prioridad de opt-out/urgencia/garantías y ausencia de promesas. No puntuar por coincidencia literal del texto ilustrativo.
4. **Reanálisis:** para cada par `beforeAfterPairs`, comprobar hechos nuevos, conservación de evidencias antiguas, distinción entre rectificación/contradicción/cambio de intención y evolución adecuada de incidencias/próxima actuación.

Publicar **métricas separadas**. La tasa de alucinaciones, las atribuciones a asesor, las violaciones de no contacto y las promesas financieras deben destacarse como fallos críticos aunque la cobertura general sea elevada. Los casos con interpretaciones razonables alternativas se describen en `annotationNotes.acceptableAlternatives`.

## Limitaciones y supuestos

- Corpus sintético manual, pequeño y no calibrado con conversaciones reales: mide regresión dirigida, no rendimiento representativo de producción.
- Las dificultades y la intervención ideal son anotaciones curatoriales; conviene un segundo anotador y acuerdo interanotador antes de utilizarlo como benchmark de contratación o aceptación formal.
- Moneda, neto/bruto y expresiones relativas no se inventan cuando el cliente no las concreta.
- Ni todos los campos omitidos son necesariamente bloqueantes ni todas las preguntas comerciales tienen FAQ verificada. El modelo no puede prometer aprobación ni resultados de vivienda.
- El contrato real de `/api/intake` no figura en la solicitud: pendiente adaptador HTTP y evaluación end-to-end real. Este ZIP **no afirma** haber ejecutado un LLM ni un servidor de Libeen.

## Control de cambios

Para ampliar el corpus, conservar `caseId`/`snapshotId`, crear nuevas versiones y validar citas, referencias, categorías y continuaciones. No modificar gold para que coincida con resultados del modelo: documentar desacuerdos y revisiones humanas.

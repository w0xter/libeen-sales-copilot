# Informe de validación — Libeen AI Lead Intake V0

**Fecha:** 2026-11-15  ·  **Versión:** 1.0.0
**Resultado estructural:** 14/14 comprobaciones superadas.

## Comprobaciones ejecutadas

| Comprobación | Estado | Evidencia |
|---|---|---|
| 24 expedientes y 8 continuaciones | PASS | 24 expedientes, 8 continuaciones, 32 snapshots |
| Categorías exactamente distribuidas | PASS | {'simple': 6, 'incomplete_ambiguous': 6, 'difficult_attribution': 4, 'contradictions_corrections': 4, 'sensitive_exceptional': 4} |
| IDs únicos y gold 1:1 | PASS | 32 IDs |
| Parser y secuencia de mensajes | PASS | Intervenciones con prefijos válidos, IDs continuos y saltos de párrafo; errores=[] |
| messageId existente y cita literal de Cliente | PASS | citas inválidas=0; roles erróneos=0; detalles=[] |
| Contrato de campos, enums e incidencias | PASS | errores=0, muestra=[] |
| No inferencias desde audio | PASS | extracciones sobre audio=0 |
| Continuaciones conservan conversación y hechos previos | PASS | errores=0 |
| 3 a 10 turnos iniciales | PASS | mín=4, máx=6 |
| 8 patrones de continuación únicos | PASS | ['changed_product_interest', 'income_net_gross_clarified', 'debt_inclusion_clarified', 'pending_answer_resolved', 'amount_correction', 'genuine_conflict', 'sensitive_opt_out', 'new_facts_change_next_question'] |
| Cobertura de 7 campos y 4 incidencias | PASS | 7 campos y tipos missing/ambiguous/inaccessible/sensitive presentes |
| Casos no duplicados de forma superficial | PASS | 24 descripciones y 24 conversaciones únicas; auditoría semántica manual adicional |
| Sin identificadores sensibles ni aparentes credenciales | PASS | matches={} |
| Hechos restringidos a citas literales respaldadas | PASS | Validación estructural fuerte; interpretación semántica requiere revisión humana del benchmark |

## Cobertura y diversidad

- Distribución por categoría (expedientes originales): {'simple': 6, 'incomplete_ambiguous': 6, 'difficult_attribution': 4, 'contradictions_corrections': 4, 'sensitive_exceptional': 4}.
- Dificultades (32 snapshots): {'easy': 7, 'medium': 9, 'hard': 16}.
- Intervenciones ideales: {'clarification': 17, 'human_review': 2, 'none': 13}.
- Tipos de incidencia: {'ambiguous': 10, 'inaccessible': 2, 'missing': 22, 'sensitive': 5}.
- Snapshots con cada campo presente: {'interest': 27, 'location': 31, 'horizon': 21, 'buyers': 29, 'income': 23, 'savings': 25, 'debts': 16}.
- Nueve escenarios económicos/sujetos cubiertos: individuales, conjuntos, variables, netos, brutos, sin base, ahorros explícitos a cero, cuotas incluidas y no incluidas, importes hipotéticos (excluidos).
- Parejas antes/después: LBE-02-S0→LBE-02-S1, LBE-07-S0→LBE-07-S1, LBE-09-S0→LBE-09-S1, LBE-13-S0→LBE-13-S1, LBE-17-S0→LBE-17-S1, LBE-18-S0→LBE-18-S1, LBE-21-S0→LBE-21-S1, LBE-23-S0→LBE-23-S1.

## Revisión crítica del ground truth

- La verificación de `quote` y `messageId` demuestra anclaje textual, pero **no prueba automáticamente que cada interpretación semántica sea la única posible**. Se anotaron incertidumbres y relaciones entre afirmaciones; se recomienda segunda revisión humana ciega.
- Los casos de cantidades sin moneda no se convierten a euros por inferencia. Un validador adicional que normalice importes deberá tolerar diferentes representaciones fieles.
- En contradicciones, correcciones y cambios de opinión, la extracción esperada retiene declaraciones históricas. La vista consolidada debe distinguir vigencia frente a evidencia previa.
- `sensitive` agrupa urgencia, garantía escrita, opt-out, privacidad e inyección: no todos tienen idéntico tratamiento. La prioridad viene especificada mediante `effect` y la intervención ideal.
- La validación de ausencia de PII se basa en patrones para emails, IBAN, DNI/NIE, URL y teléfonos; no certifica anonimato universal. Se hizo además una revisión editorial de las historias inventadas.
- Diversidad revisada por categoría, localización, profesión, sujeto, cifras y fallo dominante; no hay duplicados exactos o guiones deliberadamente repetidos. La ausencia de duplicados semánticos profundos no puede demostrarse solo con hashes.
- No se ha ejecutado `POST /api/intake` ni ningún modelo: este informe mide **el dataset generado**, no la calidad del producto.

## Riesgos residuales y próximos controles

1. Añadir segundo anotador independiente y medir acuerdo en extracción e intervención.
2. Añadir evaluación de equivalencia semántica controlada para fechas, moneda y matices de interés.
3. Una vez publicado el DTO de `/api/intake`, crear adaptador de ejecución y registrar salida real por snapshot.
4. Mantener como fallos críticos los permisos, aprobaciones, suplantación del asesor e invenciones desde audio.

Todos los casos y cifras son ficticios; los umbrales de elegibilidad financiera de Libeen no son conocidos ni están presentes en el corpus.

## Checksums de archivos principales (SHA-256)

- `cases.jsonl`: `9d7c022b19a4fd99a60093fefbc8a61f7b311d1975d6b3d20a66bc11fc27cd9e`
- `gold.jsonl`: `09510d403f7e992ec6d3d6c5e0526bda65034138cbbdd445df2a906d06430aa3`
- `manifest.json`: `adb76785f88ec32eeda7b319ece1a2e1d116d23ed6d9a5dffa2e7a8566be6835`

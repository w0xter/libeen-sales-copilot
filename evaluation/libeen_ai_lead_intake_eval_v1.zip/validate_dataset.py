#!/usr/bin/env python3
# Validador estructural independiente para archivos exportados. Python 3.10+.
import json, pathlib, collections, re, sys
root=pathlib.Path(__file__).resolve().parent
cases=[json.loads(s) for s in (root/'cases.jsonl').read_text(encoding='utf8').splitlines()]
gold=[json.loads(s) for s in (root/'gold.jsonl').read_text(encoding='utf8').splitlines()]
manifest=json.loads((root/'manifest.json').read_text(encoding='utf8'))
fs={'interest','location','horizon','buyers','income','savings','debts'}
errors=[]
def test(cond,msg):
 if not cond: errors.append(msg)
ci={r['snapshotId']:r for r in cases};gi={r['snapshotId']:r for r in gold}
test(len(cases)==32 and len(gold)==32,'Deben existir 32 snapshots y 32 gold')
test(len(ci)==len(cases)==len(gi)==len(gold),'IDs duplicados o falta gold')
original=[r for r in cases if not r['isContinuation']];continued=[r for r in cases if r['isContinuation']]
test(len(original)==24 and len(continued)==8,'Distribución 24/8 incorrecta')
test(dict(collections.Counter(r['category'] for r in original))=={'simple':6,'incomplete_ambiguous':6,'difficult_attribution':4,'contradictions_corrections':4,'sensitive_exceptional':4},'Distribución categorías incorrecta')
pattern=re.compile(r'^(Cliente|Libeen|Asesor): (.*)$')
for r in cases:
 sid=r['snapshotId'];turns=r['conversation'].split('\n\n');valid=[pattern.fullmatch(x) for x in turns]
 test(all(valid),f'{sid}: formato parser incorrecto')
 if not all(valid):continue
 test(not r['isContinuation'] or (r['previousSnapshotId'] in ci and r['conversation'].startswith(ci[r['previousSnapshotId']]['conversation']+'\n\n')),f'{sid}: historial de continuación cambiado')
 if not r['isContinuation']:test(3<=len(turns)<=10,f'{sid}: turno inicial fuera de 3..10')
 g=gi.get(sid)
 if g is None: continue
 test(set(g['expectedExtraction'])==fs,f'{sid}: falta campo')
 for field,cands in g['expectedExtraction'].items():
  for cand in cands:
   mi=re.fullmatch(r'm(\d+)',cand['messageId'])
   test(mi is not None and 1<=int(mi.group(1))<=len(valid),f'{sid}: messageId no existe')
   if mi is None or not (1<=int(mi.group(1))<=len(valid)):continue
   m=valid[int(mi.group(1))-1]
   test(m.group(1)=='Cliente',f'{sid}: extracción atribuida al asesor')
   test(cand['quote'] in m.group(2),f'{sid}: quote no literal {cand["quote"]!r}')
   test(not m.group(2).startswith('[audio de'),f'{sid}: extracción basada en audio')
   test(cand['field']==field,f'{sid}: campo incorrecto')
for r in continued:
 p=gi[r['previousSnapshotId']];g=gi[r['snapshotId']]
 for f in fs:test(g['expectedExtraction'][f][:len(p['expectedExtraction'][f])]==p['expectedExtraction'][f],f'{r["snapshotId"]}: evidencia histórica alterada')
test(manifest['originalCases']==24 and manifest['snapshots']==32,'Manifest inconsistente')
print('PASS: dataset estructuralmente válido.' if not errors else 'FAIL: '+str(len(errors))+' errores')
for error in errors[:30]:print(' -',error)
sys.exit(bool(errors))
